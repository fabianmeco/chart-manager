// The file contents for the current environment will overwrite these during build.
// The build system defaults to the dev environment which uses `environment.ts`, but if you do
// `ng build --env=prod` then `environment.prod.ts` will be used instead.
// The list of which env maps to which file can be found in `.angular-cli.json`.

export const environment = {
  production: false,
  firebase: {
    apiKey: "AIzaSyC02k6Bt-SqF2BTNZa7dDhjSPMyjc8l-ak",
    authDomain: "chart-manager-721ea.firebaseapp.com",
    databaseURL: "https://chart-manager-721ea.firebaseio.com",
    projectId: "chart-manager-721ea",
    storageBucket: "",
    messagingSenderId: "774121577984"
  }
};
